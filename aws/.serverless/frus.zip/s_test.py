import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='desipilla',
    application_name='frus',
    app_uid='53wxPPbKWNJTYjDxXR',
    org_uid='JYrFbVjR4TQZB0n4Xc',
    deployment_uid='fef31b80-962f-459a-acb8-feb9c3e00022',
    service_name='frus',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.7.0',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'frus-dev-test', 'timeout': 180}
try:
    user_handler = serverless_sdk.get_user_handler('test.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
